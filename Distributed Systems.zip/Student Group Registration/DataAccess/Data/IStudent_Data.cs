﻿using DataAccess.Models;

namespace DataAccess.Data
{
    public interface IStudent_Data
    {
        Task<Group_Details_Model> get_group_details(int group_NO, int year, int semester);
        Task<IEnumerable<Student_Model>> get_student(int stud_Univ_ID);
        Task<IEnumerable<Group_Model>> get_groups(int year, int semester);
        Task<IEnumerable<Group_Model>> get_groups_include_course(String course_name);
        Task register_student(Student_Model student);
        Task update_student(Student_Model student);
        Task delete_student(int stud_Univ_ID);
    }
}