﻿using DataAccess.DbAccess;
using DataAccess.Models;

namespace DataAccess.Data;

public class Student_Data : IStudent_Data
{
    private readonly ISqlDataAccess _db;

    public Student_Data(ISqlDataAccess db)
    {
        _db = db;
    }


    public Task<IEnumerable<Group_Model>>
        get_groups(int year, int semester) =>
        _db.LoadData<Group_Model, dynamic>
        ("dbo.sp_Students_Group_GetAll", new { year, semester });

    public Task<IEnumerable<Group_Model>>
        get_groups_include_course(String course_name) =>
        _db.LoadData<Group_Model, dynamic>
        ("dbo.sp_Group_GetAll_By_Course", new { course_name });

    public Task register_student(Student_Model student) =>
    _db.SaveData("dbo.sp_Student_Insert", student);

    public Task<IEnumerable<Student_Model>> get_student(int stud_Univ_ID) =>
        _db.LoadData<Student_Model, dynamic>
        ("dbo.sp_Student_Get", new { stud_Univ_ID = stud_Univ_ID });

    public Task update_student(Student_Model student) =>
        _db.SaveData("dbo.sp_Student_Update", student);

    public Task delete_student(int stud_Univ_ID) =>
        _db.SaveData("dbo.sp_Student_Delete", new { stud_Univ_ID = stud_Univ_ID });

    public async Task<Group_Details_Model>
        get_group_details(int group_No, int year, int semester)
    {

        var lectures = await _db.LoadData<Group_Details_Model.Lecture, dynamic>
        ("dbo.sp_Group_Details_Get", new { group_No, year, semester });

        var students = await _db.LoadData<Group_Details_Model.Student, dynamic>
        ("dbo.sp_Students_Group_GetAll", new { group_No, year, semester });

        Group_Details_Model groupDetails
            = new Group_Details_Model(group_No, year, semester, lectures, students);

        return groupDetails;
    }
}
