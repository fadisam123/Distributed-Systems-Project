﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Group_Model
    {
        public int Group_No { get; set; }
        public int students_registered_No { get; set; }
    }
}
