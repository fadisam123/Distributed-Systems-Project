﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Group_Details_Model
    {
        public class Lecture
        {
            public String? course_name { get; set; }
            public String? lab_name { get; set; }
            public int day { get; set; }
            public TimeSpan time { get; set; }
            public int week_No { get; set; }
        }

        public class Student
        {
            public String? fname { get; set; }
            public String? lname { get; set; }
        }

        public int group_No { get; set; }
        public int year { get; set; }
        public int semester { get; set; }

        public IEnumerable<Lecture> lectures { get; set; }

        public IEnumerable<Student> students { get; set; }

        public Group_Details_Model(int group_No, int year, int semester, IEnumerable<Lecture> lectures, IEnumerable<Student> students)
        {
            this.group_No = group_No;
            this.year = year;
            this.semester = semester;
            this.lectures = lectures;
            this.students = students;
        }
    }
}
