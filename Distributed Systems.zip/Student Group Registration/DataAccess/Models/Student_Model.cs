﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Student_Model
    {
        public int stud_Univ_ID { get; set; }
        public string? fName { get; set; }
        public string? lName { get; set; }
        public int group_No { get; set; }
        public int year { get; set; }
        public int semester { get; set; }
    }
}
