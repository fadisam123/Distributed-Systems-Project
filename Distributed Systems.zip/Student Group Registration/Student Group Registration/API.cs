﻿namespace Student_Group_Registration;

public static class API
{
    public static void ConfigureApi(this WebApplication app)
    {
        app.MapGet("/Student/{stud_Univ_ID}", Get_Student);
        app.MapPost("/Register", Register_Student);
        app.MapPut("/Register", Update_Student);
        app.MapDelete("/Register/{stud_Univ_ID}", Delete_Student);
        app.MapGet("/Groups/{year}/{semester}", Get_Groups);
        app.MapGet("/Groups/{course}", Get_Groups_Include_Course);
        app.MapGet("/GroupDetails/{group_NO}/{year}/{semester}", Get_Group_Details);
    }

    private static async Task<IResult>
        Get_Student(int stud_Univ_ID, IStudent_Data student_data)
    {
        try
        {
            var results = await student_data.get_student(stud_Univ_ID);
            if (results.Count() == 0) return Results.NotFound();
            return Results.Ok(results);
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult>
        Register_Student(Student_Model student, IStudent_Data student_data)
    {
        try
        {
            var student_exist = await student_data.get_student(student.stud_Univ_ID);
            if (student_exist.Count() != 0)
                return Results.Conflict($"The student {student_exist.First().fName} {student_exist.First().lName} is already registered in group {student_exist.First().group_No}");

            await student_data.register_student(student);
            return Results.Created($"/CheckStudent/{student.stud_Univ_ID}", student);
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult>
        Update_Student(Student_Model student, IStudent_Data student_data)
    {
        try
        {
            var student_exist = await student_data.get_student(student.stud_Univ_ID);
            if (student_exist.Count() == 0)
                return Results.NotFound($"The student with number {student.stud_Univ_ID} does not exist");

            await student_data.update_student(student);
            return Results.Ok(student);
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult>
        Delete_Student(int stud_Univ_ID, IStudent_Data student_data)
    {
        try
        {
            var student_exist = await student_data.get_student(stud_Univ_ID);
            if (student_exist.Count() == 0)
                return Results.NotFound($"The student with number {stud_Univ_ID} does not exist");

            await student_data.delete_student(stud_Univ_ID);
            return Results.Ok();
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult>
        Get_Groups(int year, int semester, IStudent_Data student_data)
    {
        try
        {
            var results = await student_data.get_groups(year, semester);
            if (results.Count() == 0) return Results.NotFound();
            return Results.Ok(results);
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult>
        Get_Groups_Include_Course(String course_name, IStudent_Data student_data)
    {
        try
        {
            var results = await student_data.get_groups_include_course(course_name);
            if (results.Count() == 0) return Results.NotFound();
            return Results.Ok(results);
        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

    private static async Task<IResult>
        Get_Group_Details(int group_NO, int year, int semester, IStudent_Data student_data)
    {
        try
        {
            var result = await student_data.get_group_details(group_NO, year, semester);
            if (result.lectures.Count() == 0) return Results.NotFound("Group does not exist");
            return Results.Ok(result);

        }
        catch (Exception ex)
        {
            return Results.Problem(ex.Message);
        }
    }

}
