﻿CREATE TABLE [dbo].[Practical_course]
(
  [course_name] NVARCHAR(450),
  [year] int NOT NULL,
  [semester] int NOT NULL,
  [is_elective] BIT NOT NULL,
  PRIMARY KEY ([course_name]),
  CONSTRAINT [FK_PracticalCourse_yearSemester]
    FOREIGN KEY ([year],[semester])
    REFERENCES [Year_semester]([year],[semester])
    ON DELETE NO ACTION
)
