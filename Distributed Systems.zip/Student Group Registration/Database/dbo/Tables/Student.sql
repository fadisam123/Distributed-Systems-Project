﻿CREATE TABLE [dbo].[Student]
(
  [stud_Univ_ID] int,
  [Fname] NVARCHAR(50) NOT NULL,
  [Lname] NVARCHAR(50) NOT NULL,
  [Group_No] int NOT NULL,
  [year] int NOT NULL,
  [semester] int NOT NULL,
  PRIMARY KEY ([stud_Univ_ID]),
    CONSTRAINT [FK_Student_Group] FOREIGN KEY (Group_No,[year],semester)
	REFERENCES [Group](Group_No,[year],semester)
	ON DELETE NO ACTION
)
