﻿CREATE TABLE [dbo].[Re_attendance_request]
(
	[stud_Univ_ID] INT NOT NULL , 
    [Group_details_ID] INT NOT NULL,

	CONSTRAINT [FK_attendance_groupDetails]
    FOREIGN KEY ([Group_details_ID])
    REFERENCES [Group_details]([ID])
    ON DELETE CASCADE,

    CONSTRAINT [FK_attendance_Student]
    FOREIGN KEY ([stud_Univ_ID])
    REFERENCES [Student]([stud_Univ_ID])
    ON DELETE CASCADE,

    PRIMARY KEY ([stud_Univ_ID], [Group_details_ID])
)
