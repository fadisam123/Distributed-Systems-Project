﻿CREATE TABLE [dbo].[Group]
(
  [Group_No] int,
  [year] int,
  [semester] int,
  [max_stud_num] int,
  PRIMARY KEY ([Group_No], [year], [semester]), 
    CONSTRAINT [FK_Group_YearSemester] FOREIGN KEY ([year],[semester])
	REFERENCES [Year_semester]([year],[semester])
	ON DELETE NO ACTION
)
