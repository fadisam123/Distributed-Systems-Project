﻿CREATE TABLE [dbo].[Group_details]
(
  [ID] int IDENTITY,
  [Group_No] int NOT NULL,
  [year] int NOT NULL,
  [semester] int NOT NULL,
  [course_name] NVARCHAR(450) NOT NULL,
  [lab_name] NVARCHAR(450) NOT NULL,
  [day] int NOT NULL,
  [time] TIME NOT NULL,
  [week_No] int,
  PRIMARY KEY ([ID]),

  CONSTRAINT [FK_GroupDetails_Group]
    FOREIGN KEY ([Group_No],[year],[semester])
    REFERENCES [Group]([Group_No],[year],[semester])
    ON DELETE CASCADE,

    CONSTRAINT [FK_GroupDetails_practicalCourse]
    FOREIGN KEY ([course_name])
    REFERENCES [Practical_course]([course_name])
    ON DELETE NO ACTION,

    CONSTRAINT [FK_GroupDetails_lab]
    FOREIGN KEY ([lab_name])
    REFERENCES [lab]([lab_name])
    ON DELETE NO ACTION,

    CONSTRAINT [FK_GroupDetails_TimeSlote]
    FOREIGN KEY ([day],[time])
    REFERENCES [Time_slote]([day],[time])
    ON DELETE NO ACTION
)
