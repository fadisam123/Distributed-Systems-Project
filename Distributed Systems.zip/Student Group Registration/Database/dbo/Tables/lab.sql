﻿CREATE TABLE [dbo].[lab]
(
	[lab_name] NVARCHAR(450) NOT NULL PRIMARY KEY
)
