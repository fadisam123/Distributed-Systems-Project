﻿CREATE TABLE [dbo].[Time_slote]
(
	[day] INT NOT NULL , 
    [time] TIME NOT NULL, 
    PRIMARY KEY ([day], [time])
)
