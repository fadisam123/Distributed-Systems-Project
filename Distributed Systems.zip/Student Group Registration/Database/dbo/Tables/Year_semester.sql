﻿CREATE TABLE [dbo].[Year_semester]
(
	[year] INT NOT NULL, 
    [semester] INT NOT NULL, 
    PRIMARY KEY ([year],[semester])
)
