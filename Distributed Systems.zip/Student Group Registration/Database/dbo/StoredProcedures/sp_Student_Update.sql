﻿CREATE PROCEDURE [dbo].[sp_Student_Update]
	@stud_Univ_ID int,
	@fName nvarchar(50),
	@lName nvarchar(50),
	@group_No int,
	@year int,
	@semester int
AS
begin
	update [dbo].[Student]
	set Fname = @fName, Lname = @lName, Group_No = @group_No, [year] = @year, semester = @semester
	where stud_Univ_ID = @stud_Univ_ID;
end