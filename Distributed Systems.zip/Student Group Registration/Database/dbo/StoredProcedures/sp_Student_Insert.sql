﻿CREATE PROCEDURE [dbo].[sp_Student_Insert]
	@stud_Univ_ID int,
	@fName nvarchar(50),
	@lName nvarchar(50),
	@group_No int,
	@year int,
	@semester int
AS
begin
	insert into [dbo].[Student] ([stud_Univ_ID],[Fname],[Lname],[Group_No],[year],[semester])
	values (@stud_Univ_ID, @fName, @lName, @group_No, @year, @semester);
end