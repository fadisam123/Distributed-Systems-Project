﻿CREATE PROCEDURE [dbo].[sp_Group_GetAll_By_Course]
	@course_name nvarchar(450)
AS
begin
	select gd.Group_No,gd.[year],gd.semester, count(*) as students_registered_No
	from [dbo].[Group_details] as gd
	inner join [Student] as s
	on gd.Group_No = s.Group_No and gd.[year] = s.[year] and gd.semester = s.semester
	where gd.course_name = @course_name
	group by gd.Group_No,gd.[year],gd.semester
end