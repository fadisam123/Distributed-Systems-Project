﻿CREATE PROCEDURE [dbo].[sp_Students_Group_GetAll]
	@Group_NO int = null,
	@year int,
	@semester int
AS
if (@Group_NO IS NULL)
begin
	select Group_No,[year],semester, count(*) as students_registered_No
	from [dbo].[Student]
	where [year] = @year and [semester] = @semester
	group by Group_No,[year],semester;
end

begin
	select *
	from [dbo].[Student]
	where Group_No = @Group_NO and [year] = @year and [semester] = @semester;
end