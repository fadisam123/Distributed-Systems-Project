﻿CREATE PROCEDURE [dbo].[sp_Group_Details_Get]
	@Group_No int,
	@year int,
	@semester int
AS
begin
	select *
	from [group_details] as gd
	where gd.Group_No = @Group_No and gd.[year] = @year and gd.semester = @semester
	ORDER BY gd.[day]
end