﻿CREATE PROCEDURE [dbo].[sp_Student_Delete]
	@stud_Univ_ID int
AS
begin
	delete
	from [dbo].[Student]
	where stud_Univ_ID = @stud_Univ_ID;
end