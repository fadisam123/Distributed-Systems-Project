﻿CREATE PROCEDURE [dbo].[sp_Student_Get]
	@stud_Univ_ID int
AS
begin
	select *
	from [dbo].[Student]
	where stud_Univ_ID = @stud_Univ_ID;
end